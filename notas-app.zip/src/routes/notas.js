const express = require('express');
const router = express.Router();

router.get('/notas/add', (req,res) => {
    res.render('notas/new-note');
});

router.post('/notas/new-note',(req,res)=>{
    const {title, description}= req.body;
    const errors = [];
    if(!title){
        errors.push({text: 'Porfavor escribe un titulo'});
    }
    if(!description){
        errors.push({text: 'Porfavor escribe una descripcion'});
    }
    if(!errors.length>0){
        errors.push('notas/new-note',{
            errors,
            title,
            description
        });
    }else{
        res.send('OK');
    }
    
});

router.get('/notas', (req,res) => {
    res.send('Notas de db');
});

module.exports = router;