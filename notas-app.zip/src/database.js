const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/notes-db-app',
    {
    //useCreateIndex: true,
    useNewUrlParser: true,
    //useFindAndModify: false
})
.then(db => console.log('DB is connected'))
.catch(err => console.log(err));

/*
{
    {Employeeid: 1; EmployeeName: Guru99};
    {Employeeid: 2; EmployeeName: Joe};
    {Employeeid: 3; EmployeeName: Martin};
}*/